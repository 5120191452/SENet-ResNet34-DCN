
import os
import random

import numpy as np
import torch
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder
from tqdm import tqdm

# from models.coatnet import coatnet_0
from resnet import resnet34

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'



def get_random_seed(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# 调用函数，设置随机种子为75 87.46
#ranbdom_seed=random.randint(100,200)
ranbdom_seed=129
get_random_seed(ranbdom_seed)
print("本轮随机种子为：",ranbdom_seed)
# 清空之前的记录文件内容
open("train_info.txt", "w").close()
open("val_info.txt", "w").close()
open("test_info.txt", "w").close()

if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

# 定义数据预处理的转换
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # 调整图像大小
    transforms.ToTensor(),  # 将图像转换为张量
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])
# Example usage:
root_dir = './7'

epochs = 50
batch_size = 8
lr = 0.001
lrf = 0.01
num_classes = 7
num_workers = 0

# 定义训练数据集
train_dataset = ImageFolder(root='./7/train', transform=transform)
val_dataset = ImageFolder(root='./7/val', transform=transform)
# 定义测试数据集
test_dataset = ImageFolder(root='./7/test', transform=transform)


train_dataloader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_dataloader = DataLoader(val_dataset, batch_size=8, shuffle=True)
test_dataloader = DataLoader(test_dataset, batch_size=8, shuffle=True)


model = resnet34(num_classes=num_classes)
model = model.to(device)

optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.9, weight_decay=0.01)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=5, gamma=0.7)
criterion = torch.nn.CrossEntropyLoss()

start_epoch = 0
checkpoint_resume = False
if checkpoint_resume:  # 恢复上次训练模型
    checkpoint = torch.load("checkpoint/lastmodel.pkl")
    model.load_state_dict(checkpoint['model_state_dict'], strict=False)
    model.cuda()
    start_epoch = checkpoint['epoch']
    scheduler.last_epoch = start_epoch
    optimizer.load_state_dict(checkpoint['opt'])

# 训练模型
best_acc = 0
for epoch in range(start_epoch, epochs):
    model.train()  # 设置模型为训练模式
    train_loss = 0.0  # 初始化训练损失为0.0
    correct = 0
    total = 0
    tqdm_batch = tqdm(train_dataloader, desc=f'Epoch {epoch + 1}/{epochs}')
    for inputs, labels in tqdm_batch:
        inputs = inputs.to(device)
        labels = labels.to(device)
        # 清除梯度
        optimizer.zero_grad()
        # 前向传播

        outputs = model(inputs)
        # 计算损失
        loss = criterion(outputs, labels)

        loss.backward()  # 对损失进行反向传播，计算梯度
        optimizer.step()  # 使用优化器更新模型参数
        train_loss += loss.item() * inputs.size(0)  # 累加批次损失值

        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    train_loss /= len(train_dataset)  # 计算平均训练损失值
    accuracy = correct / total
    print(f"第{epoch + 1}轮的训练损失为{train_loss:.4f}, 准确率为{accuracy}")
    train_info = f"Epoch {epoch + 1}/{epochs}: Train Loss: {train_loss:.4f}, Accuracy: {accuracy}\n"
    with open("train_info.txt", "a") as f:
        f.write(train_info)


    model.eval()  # 设置模型为评估模式
    val_loss = 0.0  # 初始化测试损失为0.0
    correct = 0
    total = 0

    with torch.no_grad():  # 不计算梯度值，节省内存空间和计算时间
        for inputs, labels in tqdm(val_dataloader, desc=f'Epoch {epoch + 1}/{epochs}'):
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)  # 前向传播，得到预测值
            loss = criterion(outputs, labels.long())  # 计算损失值
            val_loss += loss.item() * inputs.size(0)  # 累加批次损失值

            # 计算准确率
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    val_loss /= len(val_dataset)  # 计算平均测试损失值
    accuracy = correct / total
    print(f"第{epoch + 1}轮的验证集损失为{val_loss:.4f}, 准确率为{accuracy}")
    # 记录验证信息到txt文件
    val_info = f"Epoch {epoch + 1}/{epochs}: Validation Loss: {val_loss:.4f}, Accuracy: {accuracy}\n"
    with open("val_info.txt", "a") as f:
        f.write(val_info)


    model.eval()  # 设置模型为评估模式
    test_loss = 0.0  # 初始化测试损失为0.0
    correct = 0
    total = 0

    with torch.no_grad():  # 不计算梯度值，节省内存空间和计算时间
        for inputs, labels in tqdm(test_dataloader, desc=f'Epoch {epoch + 1}/{epochs}'):
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)  # 前向传播，得到预测值
            loss = criterion(outputs, labels.long())  # 计算损失值
            test_loss += loss.item() * inputs.size(0)  # 累加批次损失值

            # 计算准确率
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    test_loss /= len(test_dataset)  # 计算平均测试损失值
    accuracy = correct / total
    print(f"第{epoch + 1}轮的测试损失为{test_loss:.4f}, 准确率为{accuracy}")
    # 记录测试信息到txt文件
    test_info = f"Epoch {epoch + 1}/{epochs}: Test Loss: {test_loss:.4f}, Accuracy: {accuracy}\n"
    with open("test_info.txt", "a") as f:
        f.write(test_info)

    scheduler.step()  # 更新学习率

    checkpoint = {"model_state_dict": model.state_dict(),
                  "opt": optimizer.state_dict(),
                  "acc": accuracy,
                  "epoch": epoch}
    if accuracy > best_acc:
        # path_checkpoint = "./checkpoint/checkpoint_{}_epoch.pkl".format(epoch)  # 定义保存路径，包含epoch编号
        path_checkpoint = "./checkpoint/bestmodel.pkl".format(epoch)  # 定义保存路径，包含epoch编号
        torch.save(checkpoint, path_checkpoint)  # 保存字典到文件中

        print("Best model saved!")
        # 更新最佳指标
        best_acc = accuracy
    print(f"最高准确率为{best_acc}")
    print("\n")
    path_checkpoint = "./checkpoint/lastmodel.pkl".format(epoch)  # 定义保存路径，包含epoch编号
    torch.save(checkpoint, path_checkpoint)  # 保存字典到文件中
