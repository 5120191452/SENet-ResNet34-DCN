import torch
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
import matplotlib.pyplot as plt
from resnet import resnet34


# 定义数据预处理的转换
transform = transforms.Compose([
    transforms.Resize((224, 224)),  # 调整图像大小
    transforms.ToTensor(),  # 将图像转换为张量
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# 定义测试数据集
test_dataset = ImageFolder(root=r'./7/test', transform=transform)
test_dataloader = DataLoader(test_dataset, batch_size=8, shuffle=True)

# 加载ResNet50模型（包括预训练权重）
model = resnet34(num_classes=7)


# 加载预训练权重
checkpoint = torch.load("checkpoint/bestmodel.pkl")
model.load_state_dict(checkpoint['model_state_dict'], strict=False)
model.cuda()
start_epoch = checkpoint['epoch']


model.eval()

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

# 进行模型预测
true_labels = []
predicted_labels = []

with torch.no_grad():
    for inputs, labels in test_dataloader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        _, preds = torch.max(outputs, 1)
        true_labels.extend(labels.cpu().numpy())
        predicted_labels.extend(preds.cpu().numpy())

# 计算混淆矩阵
conf_matrix = confusion_matrix(true_labels, predicted_labels)

#计算特异度
# 获取每个类别的真负类数和假正类数
num_classes = len(set(true_labels))
class_specificity = []
for i in range(num_classes):
    # 计算混淆矩阵的行和列索引
    true_negative = sum([conf_matrix[j, k] for j in range(num_classes) if j != i for k in range(num_classes) if k != i])
    false_positive = sum([conf_matrix[j, i] for j in range(num_classes) if j != i])

    # 计算特异度
    specificity = true_negative / (true_negative + false_positive)
    class_specificity.append(specificity)
for i in range(num_classes):
    print(f"类别 {i} 的特异度: {class_specificity[i]}")
# 使用Seaborn绘制混淆矩阵热力图
class_names = test_dataset.classes
plt.figure(figsize=(12, 10))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('Confusion Matrix')
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=45, ha='right')
plt.show()

# 获取分类报告
class_names = test_dataset.classes
classification_rep = classification_report(true_labels, predicted_labels, target_names=class_names)
# 打印分类报告
print("\nClassification Report:")
print(classification_rep)

#将结果写入文件
output_file_path = 'result/output.txt'
# 添加名称标识
report_name = 'ResNet50_Classification_Report:'
full_classification_rep = f"{report_name}\n\n{classification_rep}"
with open(output_file_path, 'w') as file:
    file.write("Classification Report:")
    file.write(full_classification_rep)
    for i in range(num_classes):
        file.write(f"Category {i} specificity:: {class_specificity[i]}\n")
